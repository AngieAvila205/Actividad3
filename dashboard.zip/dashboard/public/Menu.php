<ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2 active" aria-current="page" href="index.php">
                <svg class="bi"><use xlink:href="#house-fill"/></svg>
                INICIO
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="vestido.php">
                <svg class="bi"><use xlink:href="#file-earmark"/></svg>
                VESTIDOS
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Zapatos.php">
                <svg class="bi"><use xlink:href="#cart"/></svg>
                ZAPATOS
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Bolsos.php">
                <svg class="bi"><use xlink:href="#people"/></svg>
                BOLSOS
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="#">
                <svg class="bi"><use xlink:href="#graph-up"/></svg>
                BORRAR
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="Actualizar.html">
                <svg class="bi"><use xlink:href="#puzzle"/></svg>
                ACTUALIZAR
              </a>
            </li>
          </ul>